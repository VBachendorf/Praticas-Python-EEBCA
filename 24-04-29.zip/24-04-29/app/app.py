import streamlit as st
import sqlite3
import pandas as pd
from cadastro import inserir_animal

# Função para inserir um novo animal no banco de dados


# Ler os dados da tabela animal e exibi-los em um DataFrame
def mostrar_animais():
    with sqlite3.connect('capirotinho.db') as conexao:
        return pd.read_sql_query("SELECT * FROM animal", conexao)

# Layout da interface
st.title('Cadastro de Animais')

# Exibir os animais atualmente cadastrados
animais = mostrar_animais()
st.dataframe(animais)

# Formulário para adicionar um novo animal
col1, col2, col3 = st.columns(3)
id_raca = col1.radio('Selecione a raça',['1','2'])
nome = col2.text_input('Digite o nome do animal', key='nome')
data_nascimento = col3.date_input('Selecione a data de nascimento', key='nascimento')
sexo = col1.number_input('Informe o Sexo do animal', key='sexo', min_value=0)
peso = col2.number_input('Informe o peso', key='peso', min_value=0)
altura = col3.number_input('Informe a altura', key='altura', min_value=0)

# Botão para enviar os dados
if st.button('Enviar dados'):
    if inserir_animal(nome, id_raca, data_nascimento, sexo, peso, altura):
        st.success('Animal cadastrado com sucesso!')
        # Atualizar a exibição dos animais após o cadastro
        animais = mostrar_animais()
        st.dataframe(animais)
    else:
        st.warning('Por favor, verifique os dados e tente novamente.')
        st.write(nome, id_raca, data_nascimento, sexo, peso, altura)
